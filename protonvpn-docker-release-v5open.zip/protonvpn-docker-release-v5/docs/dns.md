# DNS Servers

- To use custom DNS servers, you MUST disable DNS leak protection by setting `PROTONVPN_DNS_LEAK_PROTECT=0`
- If you ar using Kubernetes disable DNS leak protection to properly resolve `cluster.local` domains.
