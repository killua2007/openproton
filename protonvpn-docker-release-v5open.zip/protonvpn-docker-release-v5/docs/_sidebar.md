<!-- _sidebar.md -->

- [Getting Started](README.md)

- Advanced
    - [Healthcheck](healthcheck.md)
    - [DNS](dns.md)
    - [Bypass VPN for LAN](split-tunnel.md)

- Troubleshooting
    - [How to](troubleshooting.md)
    - [Known Issues](limitations.md)

- [Kubernetes](kubernetes.md)
- [Changelog](changelog.md)
- [Contributing](CONTRIBUTING.md)
